# -*- coding: utf-8 -*-
# @file <runner.py>
# @brief this is a start point to run python automation

import os

if __name__ == '__main__':
        os.system(f"python3 -m pytest tests/android/test_app.py -v -m sanity")

        # os.system(
        #         f"python3 -m pytest tests/{content_type}/ --html=reports/{content_package}_{tags}.html "
        #         f"--self-contained-html -q --tags={tags} -v -m {tags}")