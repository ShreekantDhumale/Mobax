import time
from appium import  webdriver
from config import configuration as config
def test_android_app():
    app_activity = 'io.testproject.demo.MainActivity'
    app_package = 'io.testproject.demo'
    emulator_id = 'emulator-971380'

    desired_capabilities  = {
        "appActivity" : app_activity,
        "appPackage":  app_package,
        "udid": emulator_id,
        "browserName" : "",
        "platformName" : "Android"
    }

    driver = webdriver.Remote(desired_capabilities=desired_capabilities)
    driver.start_activity(app_activity=app_activity,app_package=app_package)
    driver.find_element_by_id("name").send_keys("Shreekant Dhumale")
    driver.find_element_by_id("#password").send_keys("12345")
    driver.find_element_by_id("#login").click()

    time.sleep(2)
    assert driver.find_element_by_id("greetings").is_displayed()
    driver.close_app()
    driver.quit()



if __name__ == "__main__":
    test_android_app()