from src.testproject.sdk.drivers import webdriver
from src.testproject.decorator import  report
from config import configuration as cfg
import pytest
@report(project="MobaX", job="webapp")
@pytest.mark.sanity
def test_simple_test():
    driver = webdriver.Chrome()
    cfg.log_file
    driver.get("https://example.testproject.io/web/")
    driver.find_element_by_css_selector("#name").send_keys("Shreekant Dhumale")
    driver.find_element_by_css_selector("#password").send_keys("12345")
    driver.find_element_by_css_selector("#login").click()
    passed = driver.find_element_by_css_selector("#logout").is_displayed()
    print("Test passed") if passed else print("Test failed")
    driver.quit()



if __name__ == "__main__":
    test_simple_test()
