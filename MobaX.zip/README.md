**Product Mobax Test Automation**

This is an automation project to test Mobax moblile application:

**Testproject.io setup**
1. Download testProjectAgent and install it 
2. Verify agent is running or not 
http://localhost:8585
Want to configure another port -  set TP_AGENT_URL environment variable
3. Set the token, visit the site with your credentials, follow the steps on the given site.
https://app.testproject.io/#/integrations/sdk

COPY TOKEN AND CREATE ENVIRONMENT VARIABLE 
TP_DEV_TOKEN AND PASTE TOKEN


**How to Execute tests**

Install python 3.6+
Install all dependencies as described under requirements.txt
Keep you aws credentials in config/aws.json or export them
Place validator tool executable in tools/. Download from box location or refer below
Keep content package in data/mobax_package/
make sure password is properly set in configuration.py
Export required variables. DEBUG or PRODUCTION or DEVELOPEMENT and CONTENT_TYPE
e.g DEBUG=1;CONTENT_TYPE=windows
python runner.py


Testcase function should start with the keyword test_.
Python file name should start with test_ or end with _test.

Execute all test cases from all the Python files in the given directory.
pytest
Run all the test cases from the given Python file name.
pytest <file_name>
Execute specific testcase from the given Python file.
pytest <file_name>::<test_case>

print console log
pytest <testcase_to_execute> -s
