import os
import json
import logging
from pathlib import PurePath, Path
from logging.config import fileConfig
from lib.utils.dict_to_map import DictToMap
root_directory = Path(__file__).resolve().parents[1]
project_path = str(root_directory)
Path(project_path, "logs").mkdir(parents=True, exist_ok=True)
Path(project_path, "reports").mkdir(parents=True, exist_ok=True)
Path(project_path, "tools").mkdir(parents=True, exist_ok=True)
Path(project_path, "output").mkdir(parents=True, exist_ok=True)


if os.getenv("PRODUCTION"):
    with open(os.path.join(project_path, "config", f"mobax_env_production.json"), "r") as fp:
        ENV = DictToMap(json.load(fp=fp))

elif os.getenv("DEBUG"):
    with open(os.path.join(project_path, "config", f"mobax_env_debug.json"), "r") as fp:
        ENV = DictToMap(json.load(fp=fp))

elif os.getenv("DEVELOPMENT"):
    print("TEST",os.getenv("DEVELOPMENT"))
    with open(os.path.join(project_path, "config", f"mobax_env_dev.json"), "r") as fp:
        ENV = DictToMap(json.load(fp=fp))
else:
    ENV = None
    raise Exception("Please provide ENV files names in Environment variables | PRODUCTION or "
                    "DEBUG or DEVELOPMENT")


fileConfig(os.path.join(project_path, "config", 'logging_config.ini'),
           defaults={'logfilename': os.path.join(
               project_path, "logs/",
               f"development_test_automation.log")})

log_console = logging.getLogger('Mobax_Console')
log_file = logging.getLogger('Mobax_File')

logging.basicConfig(filename=r'F:\Mobax\logs\app.log', filemode='w', format='%(name)s - %(asctime)s - %(levelname)s - %(message)s',level = logging.INFO)